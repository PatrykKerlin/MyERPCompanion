from django.db import models


class PersonalModel(models.Model):
    class Meta:
        abstract = True

    first_name = models.CharField(max_length=50)
    middle_name = models.CharField(max_length=50, null=True, blank=True)
    last_name = models.CharField(max_length=100)
