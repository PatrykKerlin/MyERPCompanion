from django.core.validators import RegexValidator
from django.db import models


class AddressModel(models.Model):
    class Meta:
        abstract = True

    street = models.CharField(max_length=50, null=True, blank=True)
    house_number = models.CharField(max_length=5)
    apartment_number = models.CharField(max_length=5, null=True, blank=True)
    postal_code = models.CharField(max_length=6, validators=[
        RegexValidator(regex=r'^\d{2}-\d{3}$', message='Postal code must be in the format xx-xxx.')])
    city = models.CharField(max_length=50)
    country = models.CharField(max_length=50)
