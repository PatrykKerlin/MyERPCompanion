from django.core.validators import EmailValidator, RegexValidator
from django.db import models


class ContactModel(models.Model):
    class Meta:
        abstract = True

    phone_country_code = models.CharField(max_length=3, validators=[
        RegexValidator(regex=r'^\+[0-9]{2}$', message='Country code must start with "+" followed by 2 digits.')])
    phone_number = models.CharField(max_length=15, validators=[
        RegexValidator(regex=r'^\d+$', message='Phone number must contain only digits.')])
    email = models.EmailField(validators=[EmailValidator(message="Enter a valid email address.")])
