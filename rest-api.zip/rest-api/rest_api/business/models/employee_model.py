from django.core.validators import RegexValidator
from django.db import models

from base.models import BaseModel, AddressModel, ContactModel
from .text_choices import IdentityDocuments


class Employee(BaseModel, AddressModel, ContactModel):
    pesel = models.CharField(max_length=11, null=True, blank=True)
    date_of_birth = models.DateField()

    identity_document = models.CharField(max_length=8, choices=IdentityDocuments.choices)
    identity_document_number = models.CharField(max_length=15)

    bank_country_code = models.CharField(max_length=2)
    bank_account_number = models.CharField(max_length=26, validators=[
        RegexValidator(regex=r'^\d{26}$', message='Bank account number must be exactly 26 digits.')])
    bank_name = models.CharField(max_length=100)
    bank_swift = models.CharField(max_length=11)

    date_of_employment = models.DateField()
    position = models.CharField(max_length=100)
    department = models.CharField(max_length=100)
    salary = models.DecimalField(max_digits=10, decimal_places=2)

    def __str__(self):
        if not self.middle_name:
            return f'{self.first_name} {self.last_name}'
        return f'{self.first_name} {self.middle_name} {self.last_name}'
