from django.db import models

from base.models import BaseModel

from . import Warehouse


class Bin(BaseModel):
    warehouse = models.ForeignKey(Warehouse, on_delete=models.DO_NOTHING, related_name='bins')
    location = models.CharField(max_length=10, unique=True)

    def __str__(self):
        return f"{self.warehouse.name} - {self.location}"
