from django.db.models import TextChoices


class IdentityDocuments(TextChoices):
    PASSPORT = 'passport', 'Passport'
    ID_CARD = 'id_card', 'Identity Card'
