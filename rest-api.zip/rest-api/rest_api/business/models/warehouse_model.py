from django.db import models

from base.models import BaseModel, AddressModel


class Warehouse(BaseModel, AddressModel):
    name = models.CharField(max_length=100, unique=True)

    def __str__(self):
        return self.name
