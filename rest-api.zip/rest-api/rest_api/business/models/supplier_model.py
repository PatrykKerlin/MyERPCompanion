from django.db import models

from base.models import BaseModel, AddressModel, ContactModel, PersonalModel


class Supplier(BaseModel, AddressModel, ContactModel, PersonalModel):
    company = models.CharField(max_length=100)
    nip = models.CharField(max_length=10, unique=True)

    def __str__(self):
        return self.company
