from django.db import models

from base.models import BaseModel
from base.managers import BaseManager
from .. import Bin, Item


class BinItems(BaseModel):
    objects = BaseManager()

    class Meta:
        verbose_name = 'Bin-Items'
        verbose_name_plural = 'Bin-Items'
        db_table = 'business_bin_items'
        unique_together = ('bin', 'item')

    bin = models.ForeignKey(Bin, on_delete=models.DO_NOTHING, limit_choices_to={'is_active': True})
    item = models.ForeignKey(Item, on_delete=models.DO_NOTHING, limit_choices_to={'is_active': True})

    def __str__(self):
        return f'{self.bin} - {self.item})'
